#!/bin/bash

cd /home/ec2-user/app

# Stop any previous Node app (avoid port already in use)
pkill node || true

# Start app in background
nohup node app.js > output.log 2>&1 &